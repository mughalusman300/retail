		
		<div class="modal fade barcode-modal" id="barcode-modal">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Print Barcode</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
					</div>
					<div class="modal-body">

					</div>
				</div>
			</div>
		</div>