 <footer class="page-footer">
        <div class="footer-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-sm-6">
                        <p class="mb-0 text-muted">ColoredStrategies 2019</p>
                    </div>
                    <div class="col-sm-6 d-none d-sm-block">
                        <ul class="breadcrumb pt-0 pr-0 float-right">
                            <!-- <li class="breadcrumb-item mb-0">
                                <a href="#" class="btn-link">Review</a>
                            </li>
                            <li class="breadcrumb-item mb-0">
                                <a href="#" class="btn-link">Purchase</a>
                            </li>
                            <li class="breadcrumb-item mb-0">
                                <a href="#" class="btn-link">Docs</a>
                            </li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    
    <script src="<?= base_url(); ?>/public/asset/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/vendor/bootstrap-datepicker.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/vendor/fullcalendar.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/vendor/perfect-scrollbar.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/vendor/mousetrap.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/vendor/jquery.table2excel.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/vendor/tableHTMLExport.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.0.10/jspdf.plugin.autotable.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/libs/FileSaver/FileSaver.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/libs/js-xlsx/xlsx.core.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/libs/js-xlsx/xlsx.core.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/libs/jsPDF/jspdf.min.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/libs/jsPDF-AutoTable/jspdf.plugin.autotable.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/libs/tableExport.min.js"></script>

    <script src="<?= base_url(); ?>/public/asset/js/dore.script.js"></script>
    <script src="<?= base_url(); ?>/public/asset/js/scripts.js"></script>
    <script>
        $(document).on('keypress','input', function(e){
            var keyCode = e.which;
            if(keyCode == 13) {
                e.preventDefault();
            }
        })
    </script>
    
